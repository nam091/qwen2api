# Z2API — OpenAI/Anthropic Compatible Proxy for Z.ai

Proxy server that exposes chat.z.ai's GLM models via standard OpenAI and Anthropic API formats.

## Features

- **OpenAI Chat Completions API** (`/v1/chat/completions`) — streaming and non-streaming
- **Anthropic Messages API** (`/v1/messages`) — Claude-compatible format
- **Multi-turn conversations** — flattened into single prompt for context preservation
- **Model selection** — all Z.ai GLM models available
- **Thinking mode** — configurable: `reasoning` (delta.reasoning_content), `think` (\<think\>tags), or `strip`
- **Browser-based captcha handling** — automatic Aliyun captcha resolution via Playwright CDP
- **Token pool & rotation** — round-robin across multiple tokens
- **HMAC-SHA256 request signing** — two-level signature generation

## Architecture

```
Client (OpenAI format) → Z2API → Browser (captcha+send) → Z.ai API → SSE → Client
```

The server uses Playwright to connect to Chrome via CDP. For each request:
1. Opens a new chat in the z.ai UI
2. Selects the requested model
3. Types the user message into the textarea
4. The browser's Aliyun captcha SDK auto-generates verification tokens
5. Intercepts the outgoing API request to modify model/messages if needed
6. Captures the SSE response
7. Converts Z.ai's response format to OpenAI/Claude format

## Requirements

- **Node.js** 18+
- **Chrome browser** running with remote debugging enabled (CDP)
- **Playwright** (`npm install`)

## Setup

```bash
# Install dependencies
npm install

# Install Playwright browsers (if not using existing Chrome)
npx playwright install chromium

# Start Chrome with remote debugging (if not already running)
google-chrome --remote-debugging-port=29229 &
```

## Usage

```bash
# Basic start
TOKENS="your_z_ai_jwt_token" node server.js

# With options
PORT=8080 \
CDP_URL=http://localhost:29229 \
TOKENS="token1,token2" \
THINK_MODE=reasoning \
DEBUG=true \
node server.js
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8080` | Server port |
| `CDP_URL` | `http://localhost:29229` | Chrome DevTools Protocol URL |
| `TOKENS` | (required) | Comma-separated Z.ai JWT tokens |
| `THINK_MODE` | `reasoning` | How to expose thinking: `reasoning`, `think`, `strip` |
| `DEBUG` | `false` | Enable debug logging |
| `ADMIN_KEY` | — | Admin API auth key |
| `FE_VERSION` | `prod-fe-1.1.35` | Z.ai frontend version |

## API Endpoints

### `GET /v1/models`
List all available Z.ai models.

### `POST /v1/chat/completions`
OpenAI-compatible chat completions.

```bash
curl http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "GLM-5.1",
    "stream": true,
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

### `POST /v1/messages`
Anthropic-compatible messages API.

```bash
curl http://localhost:8080/v1/messages \
  -H "Content-Type: application/json" \
  -H "anthropic-version: 2023-06-01" \
  -d '{
    "model": "GLM-5.1",
    "max_tokens": 1024,
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

### `GET /health`
Health check.

### `GET /admin/stats`
Admin statistics (requires `ADMIN_KEY`).

## Available Models

- **GLM-5.1** — Flagship reasoning model
- **GLM-5-Turbo** — Fast reasoning model
- **GLM-5v-Turbo** — Vision model (image understanding)
- **glm-5** — Base GLM-5
- **glm-4.7** — GLM 4.7 with reasoning
- **glm-4.6v** — GLM 4.6 with vision
- **glm-4-flash** — Fast model
- And more (see `/v1/models` for full list)

## Thinking Mode

Z.ai's GLM models support chain-of-thought reasoning. Configure with `THINK_MODE`:

- **`reasoning`** (default): Sends thinking as `reasoning_content` in delta (OpenAI-compatible)
- **`think`**: Wraps thinking in `<think>...</think>` tags within content
- **`strip`**: Removes thinking entirely, only sends final answer

## Limitations

- **Latency**: ~7-15s per request due to browser UI interaction overhead
- **Concurrency**: Serialized per token (one request at a time per token)
- **Vision**: Requires images accessible to Z.ai backend (external URLs may not work)
- **Multi-turn**: History is flattened into a single prompt (not native multi-turn)

## Test Results

| Model | Status | Latency | Response |
|-------|--------|---------|----------|
| GLM-5.1 | ✅ | ~12s | Full reasoning + answer |
| GLM-5-Turbo | ✅ | ~7.5s | Fast reasoning |
| glm-5 | ✅ | ~20s | Full reasoning |
| glm-4.7 | ✅ | ~13s | Good quality |
| glm-4-flash | ✅ | ~7s | Fastest |
| GLM-5v-Turbo | ✅ | ~28s | Vision (needs CDN images) |
| Claude API | ✅ | ~6.5s | Anthropic format |
| Multi-turn | ✅ | ~11s | Context preserved |
