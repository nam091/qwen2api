# Z2API v2 — Test Results & Performance Report

**Date:** 2026-05-22  
**Version:** v2 (10 improvements)  
**Server:** Node.js + Playwright CDP  
**Browser:** Chrome (localhost:29229)

## Summary

**8/8 tests PASSED** — All features working correctly.

## Performance Comparison: v1 vs v2

| Metric | v1 (browser-wait) | v2 (route-stream) | Improvement |
|--------|-------------------|-------------------|-------------|
| TTFB (simple) | = Total (15-20s) | 7-9s | **Real-time!** |
| TTFB (complex) | = Total (80-96s) | 8-12s | **~85% faster** |
| Total (simple Q&A) | 15-20s | 8-10s | **~50% faster** |
| Total (medium) | 30-40s | 12-27s | **~35% faster** |
| Multi-turn | 38s | 13s | **~65% faster** |
| Reasoning separation | Not available | ✅ Working | **NEW** |
| Model aliases | Not available | ✅ Working | **NEW** |
| Health monitoring | Not available | ✅ Working | **NEW** |

## Detailed Test Results

| Test | Model | Latency | Status |
|------|-------|---------|--------|
| Basic Streaming | GLM-5-Turbo | 9,401ms | ✅ PASS |
| Non-streaming | GLM-5-Turbo | 7,689ms | ✅ PASS |
| Model Alias (gpt-4→GLM-5.1) | GLM-5.1 | 10,659ms | ✅ PASS |
| Reasoning Separation | GLM-5.1 | 21,706ms (100 reasoning chunks) | ✅ PASS |
| Multi-turn (3 messages) | GLM-5-Turbo | 13,052ms | ✅ PASS |
| Claude API | claude-sonnet-4→GLM-5.1 | 10,115ms | ✅ PASS |
| /v1/models endpoint | - | 375ms (14 models) | ✅ PASS |
| /health endpoint | - | instant | ✅ PASS |

## Speed Benchmark (TTFB vs Total)

| Task | Model | TTFB | Total | Chunks |
|------|-------|------|-------|--------|
| Math (1 word) | GLM-5-Turbo | 9,137ms | 10,017ms | 16 |
| Geography (1 word) | GLM-5-Turbo | 7,025ms | 7,942ms | 18 |
| Science (3 sentences) | GLM-5.1 | 12,090ms | 26,526ms | 161 |
| Creative (haiku) | GLM-5.1 | 8,701ms | 23,856ms | 166 |
| Vietnamese | GLM-5-Turbo | 8,915ms | 12,445ms | 35 |

## 10 Improvements Implemented

| # | Feature | Status | Impact |
|---|---------|--------|--------|
| 1 | **Real-time Streaming** | ✅ | TTFB < Total (was TTFB = Total) |
| 2 | **Route Intercept** (replaces Direct API*) | ✅ | Bypasses captcha requirement |
| 3 | **300s Timeout** | ✅ | No more timeouts on long tasks |
| 4 | **Multi-token LRU** | ✅ | Concurrent request support |
| 5 | **Rate Limit Queue** | ✅ | Auto-backoff on MODEL_CONCURRENCY_LIMIT |
| 6 | **Vision Upload Fix** | ✅ | Verify upload before send |
| 7 | **Thinking Toggle** | ✅ | Auto-disable for short prompts |
| 8 | **Claude Reasoning** | ✅ | Separate thinking_delta blocks |
| 9 | **Model Aliases** | ✅ | gpt-4/claude-3 → GLM models |
| 10 | **Health Monitoring** | ✅ | Auto-detect model up/down |

*Note: Z.ai requires Aliyun captcha for direct API calls. Solution: intercept browser request via Playwright route(), make upstream HTTPS request ourselves (with browser's auth/captcha headers), stream response chunks back to client in real-time.

## Architecture (v2)

```
Client → z2api (Node.js) → Playwright route() → HTTPS request (with captcha) → Z.ai API
                                                          ↓
Client ← SSE chunks ← parseSSEBuffer() ← upstreamRes.on('data') ← HTTP stream
```

Key insight: Browser handles captcha/auth, we intercept the actual HTTP response and stream it in real-time.

## How to Run

```bash
npm install
TOKENS="your_z_ai_token" CDP_URL=http://localhost:29229 node server.js
```

Environment variables:
- `TOKENS` — Z.ai JWT token(s), comma-separated
- `CDP_URL` — Chrome DevTools Protocol URL (default: http://localhost:29229)
- `PORT` — Server port (default: 8080)
- `THINK_MODE` — reasoning/think/strip (default: reasoning)
- `REQUEST_TIMEOUT` — Request timeout in ms (default: 300000)
- `DEBUG` — Enable debug logging (true/false)
