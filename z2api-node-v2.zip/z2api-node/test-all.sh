#!/bin/bash
# Z2API Test Suite — Tests all models and features
# Usage: ./test-all.sh [base_url]

BASE=${1:-http://localhost:8080}
TOKEN="test-key"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m'

PASS=0
FAIL=0
RESULTS_FILE="/tmp/z2api-test-results.md"

echo "# Z2API Test Results — $(date)" > "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

test_model() {
  local model=$1
  local prompt=$2
  local start_time=$(date +%s%N)
  
  local response=$(curl -s --max-time 120 "$BASE/v1/chat/completions" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"$model\",\"stream\":false,\"messages\":[{\"role\":\"user\",\"content\":\"$prompt\"}]}" 2>&1)
  
  local end_time=$(date +%s%N)
  local duration_ms=$(( (end_time - start_time) / 1000000 ))
  
  # Extract content
  local content=$(echo "$response" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['choices'][0]['message']['content'][:100])" 2>/dev/null)
  local error=$(echo "$response" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('error',{}).get('message',''))" 2>/dev/null)
  
  # Extract usage
  local total_tokens=$(echo "$response" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('usage',{}).get('total_tokens',0))" 2>/dev/null)
  local completion_tokens=$(echo "$response" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('usage',{}).get('completion_tokens',0))" 2>/dev/null)
  
  local tokens_per_sec=0
  if [ "$duration_ms" -gt 0 ] && [ "$completion_tokens" -gt 0 ] 2>/dev/null; then
    tokens_per_sec=$(python3 -c "print(f'{$completion_tokens / ($duration_ms / 1000):.1f}')" 2>/dev/null)
  fi
  
  if [ -n "$content" ] && [ "$content" != "None" ] && [ -z "$error" ]; then
    echo -e "${GREEN}✓${NC} $model — ${duration_ms}ms — ${tokens_per_sec} tok/s — ${content:0:60}"
    echo "| $model | ✅ | ${duration_ms}ms | ${tokens_per_sec} tok/s | ${total_tokens} | ${content:0:60}... |" >> "$RESULTS_FILE"
    PASS=$((PASS+1))
  else
    echo -e "${RED}✗${NC} $model — ${error:-no content} — ${duration_ms}ms"
    echo "| $model | ❌ | ${duration_ms}ms | — | — | ${error:-no content} |" >> "$RESULTS_FILE"
    FAIL=$((FAIL+1))
  fi
  
  # Wait between requests to avoid rate limiting
  sleep 3
}

echo "=== Z2API Test Suite ==="
echo ""

# 1. Health check
echo "--- Health Check ---"
health=$(curl -s "$BASE/health")
echo "Health: $health"
echo "" >> "$RESULTS_FILE"
echo "## Health Check" >> "$RESULTS_FILE"
echo '```json' >> "$RESULTS_FILE"
echo "$health" >> "$RESULTS_FILE"
echo '```' >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

# 2. Models list
echo ""
echo "--- Models ---"
models=$(curl -s "$BASE/v1/models" | python3 -c "import sys,json; [print(m['id']) for m in json.load(sys.stdin)['data']]" 2>/dev/null)
echo "$models"
echo "" >> "$RESULTS_FILE"
echo "## Available Models" >> "$RESULTS_FILE"
echo '```' >> "$RESULTS_FILE"
echo "$models" >> "$RESULTS_FILE"
echo '```' >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

# 3. Test each model
echo ""
echo "--- Model Tests ---"
echo "## Model Tests" >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"
echo "| Model | Status | Latency | Speed | Tokens | Preview |" >> "$RESULTS_FILE"
echo "|-------|--------|---------|-------|--------|---------|" >> "$RESULTS_FILE"

# Test key models
test_model "GLM-5.1" "What is 2+2? Answer in one word."
test_model "GLM-5-Turbo" "Name the capital of France in one word."
test_model "glm-4.7" "What color is the sky? One word."
test_model "glm-4-flash" "Name a planet. One word."
test_model "glm-4-air-250414" "Say hello."

echo ""
echo "--- Summary ---"
echo "Passed: $PASS"
echo "Failed: $FAIL"
echo "" >> "$RESULTS_FILE"
echo "## Summary" >> "$RESULTS_FILE"
echo "- Passed: $PASS" >> "$RESULTS_FILE"
echo "- Failed: $FAIL" >> "$RESULTS_FILE"

echo ""
echo "Full results: $RESULTS_FILE"
