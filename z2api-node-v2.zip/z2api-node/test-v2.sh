#!/bin/bash
# Comprehensive Z2API v2 Test Suite
# Tests: Streaming, Models, Multi-turn, Claude API, Reasoning, Model Aliases

BASE="http://localhost:8080"
RESULTS=""
PASS=0
FAIL=0

log() { echo -e "\n\033[1;36m[$1]\033[0m $2"; }
ok() { PASS=$((PASS+1)); RESULTS+="| $1 | $2 | $3 | ✅ PASS |\n"; }
fail() { FAIL=$((FAIL+1)); RESULTS+="| $1 | $2 | $3 | ❌ FAIL |\n"; }

echo "============================================"
echo "  Z2API v2 — Comprehensive Test Suite"
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================"

# Test 1: Basic streaming — GLM-5-Turbo
log "TEST 1" "Basic streaming (GLM-5-Turbo) — simple math"
START=$(date +%s%3N)
RESP=$(curl -s --max-time 60 "$BASE/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{"model":"GLM-5-Turbo","messages":[{"role":"user","content":"What is 3+5? Just the number."}],"stream":true,"enable_thinking":false}')
END=$(date +%s%3N)
LATENCY=$(( (END - START) ))
CONTENT=$(echo "$RESP" | grep '"content"' | tail -1)
if echo "$CONTENT" | grep -q "8"; then
  ok "Test 1: Basic Streaming" "GLM-5-Turbo" "${LATENCY}ms"
else
  fail "Test 1: Basic Streaming" "GLM-5-Turbo" "${LATENCY}ms (no '8' in response)"
fi

sleep 2

# Test 2: Non-streaming
log "TEST 2" "Non-streaming (GLM-5-Turbo)"
START=$(date +%s%3N)
RESP=$(curl -s --max-time 60 "$BASE/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{"model":"GLM-5-Turbo","messages":[{"role":"user","content":"Capital of Japan? One word."}],"stream":false,"enable_thinking":false}')
END=$(date +%s%3N)
LATENCY=$(( (END - START) ))
if echo "$RESP" | grep -qi "tokyo"; then
  ok "Test 2: Non-streaming" "GLM-5-Turbo" "${LATENCY}ms"
else
  fail "Test 2: Non-streaming" "GLM-5-Turbo" "${LATENCY}ms"
  echo "  Response: $(echo $RESP | head -c 200)"
fi

sleep 2

# Test 3: Model alias — gpt-4
log "TEST 3" "Model alias (gpt-4 → GLM-5.1)"
START=$(date +%s%3N)
RESP=$(curl -s --max-time 90 "$BASE/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{"model":"gpt-4","messages":[{"role":"user","content":"What is the largest ocean? One word."}],"stream":true,"enable_thinking":false}')
END=$(date +%s%3N)
LATENCY=$(( (END - START) ))
if echo "$RESP" | grep -qi "pacific"; then
  ok "Test 3: Model Alias (gpt-4)" "GLM-5.1" "${LATENCY}ms"
else
  fail "Test 3: Model Alias (gpt-4)" "GLM-5.1" "${LATENCY}ms"
  echo "  Response: $(echo $RESP | tail -5)"
fi

sleep 2

# Test 4: Thinking mode — reasoning separation
log "TEST 4" "Reasoning separation (GLM-5.1 with thinking)"
START=$(date +%s%3N)
RESP=$(curl -s --max-time 90 "$BASE/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{"model":"GLM-5.1","messages":[{"role":"user","content":"What is 15 * 7? Show your reasoning step by step."}],"stream":true}')
END=$(date +%s%3N)
LATENCY=$(( (END - START) ))
HAS_REASONING=$(echo "$RESP" | grep -c "reasoning_content")
HAS_CONTENT=$(echo "$RESP" | grep -c '"content"')
if [ "$HAS_REASONING" -gt 0 ] && [ "$HAS_CONTENT" -gt 0 ]; then
  ok "Test 4: Reasoning Separation" "GLM-5.1" "${LATENCY}ms (${HAS_REASONING} reasoning chunks)"
else
  fail "Test 4: Reasoning Separation" "GLM-5.1" "${LATENCY}ms"
fi

sleep 2

# Test 5: Multi-turn conversation
log "TEST 5" "Multi-turn (context retention)"
START=$(date +%s%3N)
RESP=$(curl -s --max-time 90 "$BASE/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{"model":"GLM-5-Turbo","messages":[{"role":"user","content":"My name is TestBot999."},{"role":"assistant","content":"Nice to meet you, TestBot999!"},{"role":"user","content":"What is my name?"}],"stream":true,"enable_thinking":false}')
END=$(date +%s%3N)
LATENCY=$(( (END - START) ))
if echo "$RESP" | grep -qi "TestBot999"; then
  ok "Test 5: Multi-turn" "GLM-5-Turbo" "${LATENCY}ms"
else
  fail "Test 5: Multi-turn" "GLM-5-Turbo" "${LATENCY}ms"
  echo "  Response: $(echo $RESP | tail -5)"
fi

sleep 2

# Test 6: Claude API
log "TEST 6" "Claude API (/v1/messages)"
START=$(date +%s%3N)
RESP=$(curl -s --max-time 90 "$BASE/v1/messages" \
  -H "Content-Type: application/json" \
  -H "x-api-key: test" \
  -H "anthropic-version: 2023-06-01" \
  -d '{"model":"claude-sonnet-4-20250514","messages":[{"role":"user","content":"What is 7*8? Just the number."}],"max_tokens":100,"stream":false}')
END=$(date +%s%3N)
LATENCY=$(( (END - START) ))
if echo "$RESP" | grep -qi "56"; then
  ok "Test 6: Claude API" "claude-sonnet-4→GLM-5.1" "${LATENCY}ms"
else
  fail "Test 6: Claude API" "claude-sonnet-4→GLM-5.1" "${LATENCY}ms"
  echo "  Response: $(echo $RESP | head -c 300)"
fi

sleep 2

# Test 7: Models endpoint with health
log "TEST 7" "/v1/models endpoint"
START=$(date +%s%3N)
RESP=$(curl -s --max-time 30 "$BASE/v1/models")
END=$(date +%s%3N)
LATENCY=$(( (END - START) ))
MODEL_COUNT=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('data',[])))" 2>/dev/null || echo "0")
if [ "$MODEL_COUNT" -gt 0 ]; then
  ok "Test 7: Models Endpoint" "-" "${LATENCY}ms (${MODEL_COUNT} models)"
else
  fail "Test 7: Models Endpoint" "-" "${LATENCY}ms"
  echo "  Response: $(echo $RESP | head -c 200)"
fi

# Test 8: Health endpoint
log "TEST 8" "/health endpoint"
RESP=$(curl -s --max-time 10 "$BASE/health")
if echo "$RESP" | grep -q "ok"; then
  ok "Test 8: Health Check" "-" "instant"
else
  fail "Test 8: Health Check" "-" "-"
fi

echo ""
echo "============================================"
echo "  RESULTS SUMMARY"
echo "============================================"
echo ""
echo "| Test | Model | Latency | Status |"
echo "|------|-------|---------|--------|"
echo -e "$RESULTS"
echo ""
echo "PASSED: $PASS / $((PASS+FAIL))"
echo "FAILED: $FAIL / $((PASS+FAIL))"
echo ""
echo "============================================"
