#!/bin/bash
# Speed comparison: measure TTFB vs total time for streaming
BASE="http://localhost:8080"

echo "============================================"
echo "  Z2API v2 — Speed Benchmark"  
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================"
echo ""

# Function to measure streaming with TTFB
measure_stream() {
  local MODEL=$1
  local PROMPT=$2
  local DESC=$3
  
  local TMPFILE=$(mktemp)
  local START=$(date +%s%3N)
  local FIRST_CHUNK=0
  local TOTAL_CHUNKS=0
  local CONTENT_LEN=0
  
  curl -sN --max-time 120 "$BASE/v1/chat/completions" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"$PROMPT\"}],\"stream\":true,\"enable_thinking\":false}" > "$TMPFILE" 2>/dev/null &
  local PID=$!
  
  # Wait for first data
  while [ ! -s "$TMPFILE" ] && kill -0 $PID 2>/dev/null; do
    sleep 0.1
  done
  FIRST_CHUNK=$(date +%s%3N)
  
  # Wait for completion
  wait $PID 2>/dev/null
  local END=$(date +%s%3N)
  
  local TTFB=$(( FIRST_CHUNK - START ))
  local TOTAL=$(( END - START ))
  TOTAL_CHUNKS=$(grep -c "^data:" "$TMPFILE" || echo 0)
  
  # Count content characters (non-reasoning)
  CONTENT_LEN=$(grep '"content"' "$TMPFILE" | sed 's/.*"content":"\([^"]*\)".*/\1/g' | wc -c)
  
  echo "  $DESC"
  echo "    Model: $MODEL | TTFB: ${TTFB}ms | Total: ${TOTAL}ms | Chunks: $TOTAL_CHUNKS | Content: ~${CONTENT_LEN} chars"
  echo ""
  
  rm -f "$TMPFILE"
}

echo "── Simple questions (should be fast) ──"
echo ""
measure_stream "GLM-5-Turbo" "What is 2+2? Just the number." "Math (1 word answer)"
sleep 3
measure_stream "GLM-5-Turbo" "Capital of France? One word." "Geography (1 word)"  
sleep 3

echo "── Medium complexity ──"
echo ""
measure_stream "GLM-5.1" "Explain photosynthesis in 3 sentences." "Science (3 sentences)"
sleep 3
measure_stream "GLM-5.1" "Write a haiku about rain." "Creative (haiku)"
sleep 3

echo "── Vietnamese language ──"
echo ""
measure_stream "GLM-5-Turbo" "Xin chào! Bạn có khỏe không?" "Vietnamese greeting"
sleep 3

echo "============================================"
echo "  Comparison with v1:"
echo "  v1 TTFB = Total time (no streaming)"
echo "  v2 TTFB < Total time (real-time chunks!)"
echo "============================================"
