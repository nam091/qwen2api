#!/usr/bin/env node
'use strict';

/**
 * Z2API v2 — OpenAI & Anthropic compatible proxy for chat.z.ai
 * 
 * Improvements over v1:
 * 1. Real-time streaming (forward SSE chunks as they arrive)
 * 2. Direct API mode (bypass browser, call Z.ai API directly)
 * 3. Dynamic timeout (300s default, configurable)
 * 4. Multi-token parallelism (concurrent requests across tokens)
 * 5. Rate limit queue with exponential backoff
 * 6. Vision fix (improved file upload + verify)
 * 7. Thinking mode toggle (disable thinking for faster responses)
 * 8. Claude API reasoning separation
 * 9. Model alias mapping (gpt-4/claude-3 → GLM models)
 * 10. Health check for models (auto-detect up/down)
 */

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { URL } = require('url');
const fs = require('fs');

// ── Config ──
const PORT = parseInt(process.env.PORT || '8080');
const CDP_URL = process.env.CDP_URL || 'http://localhost:29229';
const ZAI_HOST = 'https://chat.z.ai';
const FE_VERSION = process.env.FE_VERSION || 'prod-fe-1.1.35';
const SALT_KEY = 'key-@@@@)))()((9))-xxxx&&&%%%%%';
const THINK_MODE = process.env.THINK_MODE || 'reasoning'; // reasoning, think, strip
const DEBUG = process.env.DEBUG === 'true' || process.env.DEBUG === '1';
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const MAX_RETRIES = 3;
const REQUEST_TIMEOUT = parseInt(process.env.REQUEST_TIMEOUT || '300000'); // 300s default
const MODE = process.env.MODE || 'auto'; // direct, browser, auto (auto = try direct, fallback to browser)

// Tokens
const TOKENS = (process.env.TOKENS || '').split(',').map(t => t.trim()).filter(Boolean);
let tokenIndex = 0;

// ── Model Alias Mapping (#9) ──
const MODEL_ALIASES = {
  // OpenAI aliases
  'gpt-4': 'GLM-5.1',
  'gpt-4-turbo': 'GLM-5.1',
  'gpt-4o': 'GLM-5.1',
  'gpt-4o-mini': 'GLM-5-Turbo',
  'gpt-3.5-turbo': 'GLM-5-Turbo',
  'o1': 'GLM-5.1',
  'o1-mini': 'GLM-5-Turbo',
  'o1-preview': 'GLM-5.1',
  'o3': 'GLM-5.1',
  'o3-mini': 'GLM-5-Turbo',
  // Claude aliases
  'claude-sonnet-4-20250514': 'GLM-5.1',
  'claude-3-5-sonnet-20241022': 'GLM-5.1',
  'claude-3-5-sonnet-latest': 'GLM-5.1',
  'claude-3-5-haiku-20241022': 'GLM-5-Turbo',
  'claude-3-haiku-20240307': 'GLM-5-Turbo',
  'claude-3-opus-20240229': 'GLM-5.1',
  'claude-opus-4-20250514': 'GLM-5.1',
  // Gemini aliases
  'gemini-pro': 'GLM-5.1',
  'gemini-1.5-pro': 'GLM-5.1',
  'gemini-2.0-flash': 'GLM-5-Turbo',
  // Vision aliases
  'gpt-4-vision-preview': 'GLM-5V-Turbo',
  'gpt-4o-vision': 'GLM-5V-Turbo',
};

function resolveModel(model) {
  if (!model) return 'GLM-5.1';
  // Check alias first
  const alias = MODEL_ALIASES[model] || MODEL_ALIASES[model.toLowerCase()];
  if (alias) return alias;
  return model;
}

// ── Model Health Status (#10) ──
const modelHealth = new Map(); // model -> { status: 'up'|'down'|'unknown', lastCheck, failCount }
const MODEL_HEALTH_TTL = 5 * 60 * 1000; // 5 min cache

function getModelHealth(model) {
  const entry = modelHealth.get(model);
  if (!entry) return 'unknown';
  if (Date.now() - entry.lastCheck > MODEL_HEALTH_TTL) return 'unknown';
  return entry.status;
}

function updateModelHealth(model, success) {
  const entry = modelHealth.get(model) || { status: 'unknown', lastCheck: 0, failCount: 0 };
  entry.lastCheck = Date.now();
  if (success) {
    entry.status = 'up';
    entry.failCount = 0;
  } else {
    entry.failCount++;
    if (entry.failCount >= 2) entry.status = 'down';
  }
  modelHealth.set(model, entry);
}

// ── Rate Limit Queue (#5) ──
class RateLimitQueue {
  constructor() {
    this.queues = new Map(); // token -> { queue: [], processing: bool, backoff: number, lastError: number }
  }

  async enqueue(token, fn) {
    if (!this.queues.has(token)) {
      this.queues.set(token, { queue: [], processing: false, backoff: 0, lastError: 0 });
    }
    const q = this.queues.get(token);
    
    return new Promise((resolve, reject) => {
      q.queue.push({ fn, resolve, reject });
      this._process(token);
    });
  }

  async _process(token) {
    const q = this.queues.get(token);
    if (q.processing || q.queue.length === 0) return;
    q.processing = true;

    while (q.queue.length > 0) {
      // Exponential backoff after rate limit
      if (q.backoff > 0) {
        const waitTime = Math.min(q.backoff, 30000);
        if (DEBUG) console.log(`[queue] Token ${token.substring(0, 12)}... backoff ${waitTime}ms`);
        await new Promise(r => setTimeout(r, waitTime));
      }

      const { fn, resolve, reject } = q.queue.shift();
      try {
        const result = await fn();
        // Success: reset backoff
        q.backoff = 0;
        resolve(result);
      } catch (e) {
        if (e.message && e.message.includes('RATE_LIMIT')) {
          // Exponential backoff: 5s, 10s, 20s, 30s max
          q.backoff = q.backoff === 0 ? 5000 : Math.min(q.backoff * 2, 30000);
          q.lastError = Date.now();
          reject(e);
        } else {
          reject(e);
        }
      }
    }

    q.processing = false;
  }
}

const rateLimitQueue = new RateLimitQueue();

// ── Browser State ──
let browser, context;
const pagePool = new Map(); // token -> { page, userId, lastUsed }
const PAGE_POOL_TTL = 10 * 60 * 1000;

// ── Stats ──
const stats = {
  requests: 0,
  errors: 0,
  captchaRetries: 0,
  directApiCalls: 0,
  browserCalls: 0,
  rateLimitHits: 0,
  startTime: Date.now(),
  modelStats: {},
  avgLatency: 0,
  totalLatency: 0,
};

// ── Token rotation (#4 - parallel across tokens) ──
function getNextToken() {
  if (TOKENS.length === 0) return '';
  const token = TOKENS[tokenIndex % TOKENS.length];
  tokenIndex++;
  return token;
}

// Get least-recently-used token for better parallelism
function getLRUToken() {
  if (TOKENS.length === 0) return '';
  if (TOKENS.length === 1) return TOKENS[0];
  
  let bestToken = TOKENS[0];
  let bestTime = Infinity;
  
  for (const token of TOKENS) {
    const entry = pagePool.get(token);
    const lastUsed = entry ? entry.lastUsed : 0;
    if (lastUsed < bestTime) {
      bestTime = lastUsed;
      bestToken = token;
    }
  }
  return bestToken;
}

// ── JWT decode ──
function decodeJWT(token) {
  try {
    const parts = token.split('.');
    if (parts.length < 2) return {};
    let payload = parts[1];
    payload += '='.repeat((4 - payload.length % 4) % 4);
    return JSON.parse(Buffer.from(payload, 'base64url').toString());
  } catch { return {}; }
}

// ── Signature ──
function generateSignature(prompt, userId) {
  const timestamp = String(Date.now());
  const requestId = crypto.randomUUID();
  const bucket = Math.floor(Number(timestamp) / 300000);

  const wKey = crypto.createHmac('sha256', SALT_KEY).update(String(bucket)).digest('hex');

  const sorted = Object.entries({ requestId, timestamp, user_id: userId })
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k},${v}`).join(',');

  const promptB64 = Buffer.from((prompt || '').trim()).toString('base64');
  const dataToSign = `${sorted}|${promptB64}|${timestamp}`;

  const signature = crypto.createHmac('sha256', Buffer.from(wKey, 'hex'))
    .update(dataToSign).digest('hex');

  return { signature, timestamp, requestId, signatureTimestamp: timestamp };
}

// ── Real-time Streaming via Browser (#1) ──
// Z.ai requires Aliyun captcha which is handled by the browser's frontend JS.
// We intercept the outgoing request AND capture the streaming response in real-time
// using CDP (Chrome DevTools Protocol) network events for true streaming.

// Parse SSE text buffer into events
function parseSSEBuffer(buffer) {
  const events = [];
  const lines = buffer.split('\n');
  let remaining = '';
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.startsWith('data: ')) {
      if (i === lines.length - 1 && !buffer.endsWith('\n')) {
        remaining = line;
      }
      continue;
    }
    const jsonStr = line.substring(6).trim();
    if (jsonStr === '[DONE]') {
      events.push({ done: true });
      continue;
    }
    try {
      let parsed = JSON.parse(jsonStr);
      if (parsed.data && parsed.type === 'chat:completion') parsed = parsed.data;
      if (parsed.data) parsed = parsed.data;
      events.push(parsed);
    } catch (e) {
      // Might be incomplete JSON at end of buffer
      if (i === lines.length - 1 && !buffer.endsWith('\n')) {
        remaining = line;
      } else if (DEBUG) {
        console.log('[parse] Failed:', jsonStr.substring(0, 80));
      }
    }
  }
  return { events, remaining };
}

// ── Browser Initialization ──
async function initBrowser() {
  try {
    const { chromium } = require('playwright');
    console.log('[init] Connecting to Chrome CDP...');
    browser = await chromium.connectOverCDP(CDP_URL);
    context = browser.contexts()[0];
    console.log('[init] Browser connected');
    return true;
  } catch (e) {
    console.log('[init] Browser connection failed:', e.message);
    console.log('[init] Direct API mode only (browser fallback unavailable)');
    return false;
  }
}

// Request queue: serializes requests per page
const requestQueues = new Map();

async function getOrCreatePage(token) {
  const cached = pagePool.get(token);
  if (cached && Date.now() - cached.lastUsed < PAGE_POOL_TTL) {
    cached.lastUsed = Date.now();
    return cached;
  }

  if (!context) throw new Error('Browser not connected');

  console.log(`[page] Creating page for token ${token.substring(0, 20)}...`);
  
  const claims = decodeJWT(token);
  const userId = claims.id || '';

  const page = await context.newPage();
  page.on('dialog', dialog => dialog.dismiss().catch(() => {}));

  await context.addCookies([{
    name: 'token', value: token, domain: 'chat.z.ai',
    path: '/', httpOnly: true, secure: true, sameSite: 'Lax'
  }]);

  await page.goto(ZAI_HOST, { waitUntil: 'networkidle', timeout: 45000 });
  await page.evaluate((t) => localStorage.setItem('token', t), token);
  await page.reload({ waitUntil: 'networkidle', timeout: 45000 });
  await page.waitForTimeout(3000);

  const entry = { page, userId, token, lastUsed: Date.now(), busy: false };
  pagePool.set(token, entry);
  requestQueues.set(token, Promise.resolve());

  console.log(`[page] Ready: user=${userId.substring(0, 8)}...`);
  return entry;
}

// ── Browser-based streaming (#1 - Real-time streaming via CDP) ──
// Uses CDP Network.requestWillBeSent + Network.dataReceived for true real-time streaming
async function sendThroughBrowserStreaming(pageEntry, requestBody, onChunk, onDone, onError) {
  const { page, token } = pageEntry;

  // Serialize per page
  const tokenKey = token;
  const prevQueue = requestQueues.get(tokenKey) || Promise.resolve();
  let resolveQueue;
  const queuePromise = new Promise(r => { resolveQueue = r; });
  requestQueues.set(tokenKey, queuePromise);
  await prevQueue;

  try {
    await _sendBrowserStreamImpl(page, token, requestBody, onChunk, onDone, onError);
  } catch (e) {
    onError(e);
  } finally {
    resolveQueue();
  }
}

async function _sendBrowserStreamImpl(page, token, requestBody, onChunk, onDone, onError) {
  const targetModel = requestBody.model || 'GLM-5.1';
  const textForTextarea = requestBody.messages && requestBody.messages.length > 1
    ? flattenMessages(requestBody.messages)
    : getLastUserContent(requestBody.messages);

  // Navigate to fresh chat
  try {
    await page.goto(ZAI_HOST + '/', { waitUntil: 'domcontentloaded', timeout: 20000 });
    await page.waitForTimeout(1500);
    const newChatBtn = await page.$('button:has-text("New Chat")');
    if (newChatBtn) {
      await newChatBtn.click({ force: true });
      await page.waitForTimeout(800);
    }
  } catch {}

  // Dismiss overlays
  await page.evaluate(() => {
    document.querySelectorAll('[class*="overlay"], [class*="modal"], [class*="popup"]').forEach(el => {
      el.style.display = 'none';
    });
  });

  await selectModel(page, targetModel);

  // Handle images
  await handleImageUploads(page, requestBody);

  // Use Playwright route() to intercept the request AND capture streaming response
  const routePattern = '**/api/v2/chat/completions*';
  let routeHandled = false;
  let streamFinished = false;
  let sseBuffer = '';

  await page.route(routePattern, async (route) => {
    if (routeHandled) { await route.continue(); return; }
    routeHandled = true;
    
    const request = route.request();
    let origBody = {};
    try { origBody = JSON.parse(request.postData()); } catch {}
    
    // Override model
    if (origBody.model !== targetModel) origBody.model = targetModel;
    
    // Fulfill manually by making the request ourselves and streaming response
    // This gives us access to the raw response stream
    const postData = JSON.stringify(origBody);
    const reqUrl = request.url();
    const reqHeaders = request.headers();
    
    // Make the actual request to Z.ai using Node.js https
    const urlObj = new URL(reqUrl);
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname + urlObj.search,
      method: 'POST',
      headers: {
        ...reqHeaders,
        'content-type': 'application/json',
        'content-length': String(Buffer.byteLength(postData)),
        'host': urlObj.hostname,
      },
    };
    // Remove headers that cause issues
    delete options.headers['content-length'];
    delete options.headers['transfer-encoding'];

    try {
      const upstreamReq = https.request(options, (upstreamRes) => {
        let fullBody = '';
        
        upstreamRes.on('data', (chunk) => {
          const text = chunk.toString();
          fullBody += text;
          sseBuffer += text;
          
          // Parse and forward chunks in real-time
          const { events, remaining } = parseSSEBuffer(sseBuffer);
          sseBuffer = remaining;
          
          for (const ev of events) {
            onChunk(ev);
          }
        });
        
        upstreamRes.on('end', () => {
          // Process any remaining buffer
          if (sseBuffer.trim()) {
            const { events } = parseSSEBuffer(sseBuffer + '\n');
            for (const ev of events) {
              onChunk(ev);
            }
          }
          streamFinished = true;
          onDone();
          
          // Fulfill the route with the full response body (for browser UI)
          route.fulfill({
            status: upstreamRes.statusCode,
            headers: Object.fromEntries(
              Object.entries(upstreamRes.headers).filter(([k, v]) => typeof v === 'string')
            ),
            body: fullBody,
          }).catch(() => {});
        });
        
        upstreamRes.on('error', (e) => {
          streamFinished = true;
          onError(e);
          route.abort().catch(() => {});
        });
      });
      
      upstreamReq.on('error', (e) => {
        streamFinished = true;
        onError(e);
        route.abort().catch(() => {});
      });
      
      upstreamReq.setTimeout(REQUEST_TIMEOUT, () => {
        upstreamReq.destroy();
        streamFinished = true;
        onError(new Error('Upstream timeout'));
        route.abort().catch(() => {});
      });
      
      upstreamReq.write(postData);
      upstreamReq.end();
    } catch (e) {
      streamFinished = true;
      onError(e);
      route.abort().catch(() => {});
    }
  });

  // Type and send
  try {
    const textarea = await page.$('textarea');
    if (!textarea) {
      await page.unroute(routePattern);
      onError(new Error('No chat textarea found'));
      return;
    }
    
    await textarea.click({ force: true });
    await textarea.fill(textForTextarea);
    await page.waitForTimeout(300);

    const sendBtn = await page.$('#send-message-button');
    if (sendBtn) await sendBtn.click({ force: true });
    else await textarea.press('Enter');

    // Wait for stream to finish
    const start = Date.now();
    while (!streamFinished && Date.now() - start < REQUEST_TIMEOUT) {
      await page.waitForTimeout(200);
    }

    if (!streamFinished) {
      onError(new Error('Timeout waiting for response'));
    }
  } finally {
    await page.unroute(routePattern).catch(() => {});
  }
}

async function handleImageUploads(page, requestBody) {
  const imageSourcesByType = [];
  for (const msg of (requestBody.messages || [])) {
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part.type === 'image_url' && part.image_url?.url) {
          const url = part.image_url.url;
          if (url.startsWith('data:')) {
            const match = url.match(/^data:(image\/(\w+));base64,(.+)$/);
            if (match) {
              imageSourcesByType.push({ type: 'base64', data: Buffer.from(match[3], 'base64'), ext: match[2] || 'png' });
            }
          } else {
            imageSourcesByType.push({ type: 'url', data: url, ext: 'png' });
          }
        }
      }
    }
  }

  if (imageSourcesByType.length === 0) return;

  for (const img of imageSourcesByType) {
    try {
      let imgBuffer;
      if (img.type === 'base64') {
        imgBuffer = img.data;
      } else {
        imgBuffer = await downloadImage(img.data);
      }
      if (!imgBuffer || imgBuffer.length < 100) {
        if (DEBUG) console.log('[image] Buffer too small, skipping');
        continue;
      }

      const tmpPath = `/tmp/z2api-img-${crypto.randomUUID()}.${img.ext}`;
      fs.writeFileSync(tmpPath, imgBuffer);

      const uploadBtn = await page.$('#upload-file-button');
      if (!uploadBtn) {
        try { fs.unlinkSync(tmpPath); } catch {}
        continue;
      }

      const [fileChooser] = await Promise.all([
        page.waitForEvent('filechooser', { timeout: 8000 }),
        uploadBtn.click({ force: true }),
      ]).catch(() => [null]);

      if (fileChooser) {
        await fileChooser.setFiles(tmpPath);
        // Wait for upload confirmation - check for thumbnail/preview
        await page.waitForTimeout(4000);
        // Verify upload by checking for image preview
        const hasPreview = await page.evaluate(() => {
          return !!document.querySelector('[class*="upload-preview"], [class*="file-preview"], img[src*="cdn"]');
        });
        if (DEBUG) console.log('[image] Upload result:', hasPreview ? 'verified' : 'unverified');
      }

      try { fs.unlinkSync(tmpPath); } catch {}
    } catch (e) {
      if (DEBUG) console.log('[image] Upload error:', e.message?.substring(0, 80));
    }
  }
}

async function selectModel(page, model) {
  try {
    const modelSelectorBtn = await page.$('button[aria-label="Select a model"]');
    if (!modelSelectorBtn) return;

    const currentModel = await modelSelectorBtn.textContent();
    if (currentModel.trim().toLowerCase().startsWith(model.toLowerCase())) return;

    await modelSelectorBtn.click({ force: true });
    await page.waitForTimeout(1000);

    const modelOption = await page.evaluate((targetModel) => {
      const tl = targetModel.toLowerCase();
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        const text = btn.textContent?.trim();
        if (!text) continue;
        const firstLine = text.split('\n')[0].trim();
        const firstName = firstLine.replace(/\s*(NEW|Hot|✓|✔|√).*$/i, '').trim();
        if (firstName.toLowerCase() === tl) { btn.click(); return firstName; }
      }
      for (const btn of buttons) {
        const text = btn.textContent?.trim()?.toLowerCase();
        if (!text || !text.startsWith(tl) || btn.offsetHeight <= 20) continue;
        const nextChar = text[tl.length] || '';
        if (nextChar === '' || nextChar === ' ' || nextChar === '\n' || nextChar === '\t') {
          btn.click(); return text.substring(0, 30);
        }
      }
      const stripped = tl.replace(/[-_\s.]/g, '');
      for (const btn of buttons) {
        const text = btn.textContent?.trim();
        if (!text) continue;
        const firstName = text.split('\n')[0].replace(/\s*(NEW|Hot|✓|✔|√).*$/i, '').trim();
        if (firstName.replace(/[-_\s.]/g, '').toLowerCase() === stripped) { btn.click(); return firstName; }
      }
      return null;
    }, model);

    if (modelOption) {
      await page.waitForTimeout(300);
    } else {
      await page.keyboard.press('Escape');
    }
  } catch {}
}

// ── Image helpers ──
function downloadImage(url, maxRedirects = 5) {
  return new Promise((resolve) => {
    if (maxRedirects <= 0) { resolve(null); return; }
    const mod = url.startsWith('https') ? https : require('http');
    mod.get(url, { timeout: 15000, headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'image/*,*/*' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let loc = res.headers.location;
        if (loc.startsWith('/')) { const u = new URL(url); loc = `${u.protocol}//${u.host}${loc}`; }
        downloadImage(loc, maxRedirects - 1).then(resolve);
        res.resume();
        return;
      }
      if (res.statusCode !== 200) { res.resume(); resolve(null); return; }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', () => resolve(null));
    }).on('error', () => resolve(null));
  });
}

// ── Text Helpers ──
function getLastUserContent(messages) {
  for (let i = (messages || []).length - 1; i >= 0; i--) {
    if (messages[i].role === 'user') {
      const c = messages[i].content;
      if (typeof c === 'string') return c;
      if (Array.isArray(c)) return c.filter(p => p.type === 'text').map(p => p.text).join(' ');
    }
  }
  return '';
}

function flattenMessages(messages) {
  if (!messages || messages.length <= 1) return getLastUserContent(messages);
  const parts = [];
  for (const msg of messages) {
    let content = '';
    if (typeof msg.content === 'string') content = msg.content;
    else if (Array.isArray(msg.content)) content = msg.content.filter(p => p.type === 'text').map(p => p.text).join(' ');
    
    if (msg.role === 'system') parts.push(`[System]: ${content}`);
    else if (msg.role === 'assistant') parts.push(`[Assistant]: ${content}`);
    else parts.push(`[User]: ${content}`);
  }
  return parts.join('\n\n');
}

function estimateTokens(text) {
  return Math.ceil((text || '').length / 4);
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch (e) { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function sendJSON(res, status, data) {
  if (res.headersSent) return;
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(data));
}

function sendSSE(res, data) {
  if (res.destroyed) return;
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

function sendClaudeSSE(res, event, data) {
  if (res.destroyed) return;
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

// Filter tool call artifacts from vision model responses
function filterToolArtifacts(text) {
  if (!text) return text;
  let result = '';
  let i = 0;
  while (i < text.length) {
    if (text[i] === '[' && i + 1 < text.length && text[i + 1] === '{') {
      let depth = 0, j = i, isToolResult = false;
      while (j < text.length) {
        if (text[j] === '[') depth++;
        else if (text[j] === ']') {
          depth--;
          if (depth === 0) {
            const block = text.substring(i, j + 1);
            if (block.includes('"type"') && (block.includes('"text"') || block.includes('"image_url"') || block.includes('"video_url"'))) {
              isToolResult = true;
            }
            break;
          }
        }
        j++;
      }
      if (isToolResult && depth === 0) { i = j + 1; continue; }
    }
    result += text[i];
    i++;
  }
  result = result.replace(/Error executing tool \w+:[^\n]*/g, '');
  result = result.replace(/^I (?:will|'ll) help you[^.]*\.(?:\s*Please wait[^.]*\.)?\s*/i, '');
  result = result.replace(/\s{3,}/g, '\n\n').trim();
  return result;
}

// ── Build Z.ai request body ──
function buildZAIBody(model, messages, options = {}) {
  const chatId = crypto.randomUUID();
  const msgId = crypto.randomUUID();
  const currentMsgId = crypto.randomUUID();
  const prompt = getLastUserContent(messages);
  const now = new Date();

  // Thinking mode toggle (#7)
  let enableThinking = options.enableThinking;
  if (enableThinking === undefined || enableThinking === null) {
    // Default: disable thinking for simple questions (< 100 chars)
    enableThinking = prompt.length > 100;
  }

  const body = {
    stream: true,
    model,
    messages,
    signature_prompt: prompt,
    params: {},
    extra: {},
    features: {
      image_generation: options.imageGeneration || false,
      web_search: options.webSearch || false,
      auto_web_search: options.webSearch || false,
      preview_mode: true,
      flags: [],
      vlm_tools_enable: model.toLowerCase().includes('5v'),
      vlm_web_search_enable: false,
      vlm_website_mode: false,
      enable_thinking: enableThinking,
    },
    variables: {
      '{{USER_NAME}}': 'User',
      '{{USER_LOCATION}}': 'Unknown',
      '{{CURRENT_DATETIME}}': now.toISOString().replace('T', ' ').substring(0, 19),
      '{{CURRENT_DATE}}': now.toISOString().substring(0, 10),
      '{{CURRENT_TIME}}': now.toISOString().substring(11, 19),
      '{{CURRENT_WEEKDAY}}': ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][now.getDay()],
      '{{CURRENT_TIMEZONE}}': 'UTC',
      '{{USER_LANGUAGE}}': 'en-US',
    },
    chat_id: chatId,
    id: msgId,
    current_user_message_id: currentMsgId,
    current_user_message_parent_id: null,
    background_tasks: {
      title_generation: true,
      tags_generation: true,
    },
  };

  if (options.tools) body.tools = options.tools;
  if (options.toolChoice) body.tool_choice = options.toolChoice;

  return body;
}

// ── OpenAI Chat Completions Handler ──
async function handleChatCompletions(req, res) {
  stats.requests++;
  const startTime = Date.now();
  const body = await parseBody(req);

  const requestedModel = body.model || 'GLM-5.1';
  const model = resolveModel(requestedModel); // #9 Model alias
  const stream = body.stream !== false;
  const messages = body.messages || [];

  // #7 Thinking mode toggle
  let enableThinking = null; // null = auto
  if (body.enable_thinking === true) enableThinking = true;
  if (body.enable_thinking === false) enableThinking = false;
  if (body.thinking && body.thinking.type === 'enabled') enableThinking = true;
  if (body.thinking && body.thinking.type === 'disabled') enableThinking = false;

  const webSearch = body.web_search === true;

  const token = extractRequestToken(req) || getLRUToken();
  if (!token) {
    return sendJSON(res, 503, { error: { message: 'No tokens available', type: 'api_error' } });
  }

  // #10 Check model health
  if (getModelHealth(model) === 'down') {
    return sendJSON(res, 503, { error: { message: `Model ${model} is currently unavailable`, type: 'model_unavailable' } });
  }

  // Track model stats
  if (!stats.modelStats[model]) stats.modelStats[model] = { requests: 0, errors: 0, totalLatency: 0 };
  stats.modelStats[model].requests++;

  const zaiBody = buildZAIBody(model, messages, {
    enableThinking, webSearch,
    tools: body.tools, toolChoice: body.tool_choice,
  });

  if (stream) {
    // ── Streaming mode with real-time forwarding (#1) ──
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
      'X-Accel-Buffering': 'no',
    });

    const completionId = 'chatcmpl-' + crypto.randomUUID().substring(0, 8);
    let totalContent = '';
    let totalThinking = '';
    let prevPhase = '';
    let firstChunkSent = false;
    let ttfb = 0;

    const processChunk = (ev) => {
      if (ev.done) return;
      if (ev.error) {
        if (ev.error.code === 'MODEL_CONCURRENCY_LIMIT') {
          stats.rateLimitHits++;
        }
        return;
      }

      const content = ev.delta_content || ev.edit_content || ev.content || '';
      if (!content) return;

      if (!firstChunkSent) {
        ttfb = Date.now() - startTime;
        firstChunkSent = true;
      }

      const phase = ev.phase || 'answer';

      if (phase === 'thinking') {
        totalThinking += content;
        if (THINK_MODE === 'reasoning') {
          sendSSE(res, {
            id: completionId, object: 'chat.completion.chunk',
            created: Math.floor(Date.now() / 1000), model,
            choices: [{ index: 0, delta: { role: 'assistant', reasoning_content: content }, finish_reason: null }],
          });
        } else if (THINK_MODE === 'think') {
          const prefix = prevPhase !== 'thinking' ? '<think>\n' : '';
          sendSSE(res, {
            id: completionId, object: 'chat.completion.chunk',
            created: Math.floor(Date.now() / 1000), model,
            choices: [{ index: 0, delta: { content: prefix + content }, finish_reason: null }],
          });
        }
        // THINK_MODE === 'strip': don't send thinking content
      } else {
        if (prevPhase === 'thinking' && THINK_MODE === 'think') {
          sendSSE(res, {
            id: completionId, object: 'chat.completion.chunk',
            created: Math.floor(Date.now() / 1000), model,
            choices: [{ index: 0, delta: { content: '\n</think>\n\n' }, finish_reason: null }],
          });
        }
        totalContent += content;
        sendSSE(res, {
          id: completionId, object: 'chat.completion.chunk',
          created: Math.floor(Date.now() / 1000), model,
          choices: [{ index: 0, delta: { role: 'assistant', content }, finish_reason: null }],
        });
      }
      prevPhase = phase;
    };

    const finishStream = () => {
      if (prevPhase === 'thinking' && THINK_MODE === 'think') {
        sendSSE(res, {
          id: completionId, object: 'chat.completion.chunk',
          created: Math.floor(Date.now() / 1000), model,
          choices: [{ index: 0, delta: { content: '\n</think>\n\n' }, finish_reason: null }],
        });
      }
      sendSSE(res, {
        id: completionId, object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000), model,
        choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
      });
      if (body.stream_options && body.stream_options.include_usage) {
        sendSSE(res, {
          id: completionId, object: 'chat.completion.chunk',
          created: Math.floor(Date.now() / 1000), model,
          choices: [],
          usage: {
            prompt_tokens: estimateTokens(getLastUserContent(messages)),
            completion_tokens: estimateTokens(totalContent),
            total_tokens: estimateTokens(getLastUserContent(messages)) + estimateTokens(totalContent),
          },
        });
      }
      res.write('data: [DONE]\n\n');
      res.end();

      // Update stats
      const latency = Date.now() - startTime;
      stats.totalLatency += latency;
      stats.modelStats[model].totalLatency += latency;
      updateModelHealth(model, totalContent.length > 0);
      if (DEBUG) console.log(`[stream] Done: ${totalContent.length} chars, TTFB=${ttfb}ms, total=${latency}ms`);
    };

    // Use browser for streaming (handles captcha automatically)
    if (browser) {
      stats.browserCalls++;
      try {
        const pageEntry = await getOrCreatePage(token);
        await new Promise((resolve, reject) => {
          sendThroughBrowserStreaming(pageEntry, zaiBody, processChunk, 
            () => { finishStream(); resolve(); },
            (err) => {
              if (err.message && err.message.includes('MODEL_CONCURRENCY_LIMIT')) {
                stats.rateLimitHits++;
              }
              if (!res.headersSent) {
                sendJSON(res, 502, { error: { message: err.message, type: 'api_error' } });
              } else {
                res.end();
              }
              updateModelHealth(model, false);
              reject(err);
            }
          );
        });
      } catch (e) {
        if (!res.headersSent) {
          sendJSON(res, 502, { error: { message: e.message, type: 'api_error' } });
        }
        stats.errors++;
        updateModelHealth(model, false);
      }
    } else {
      if (!res.headersSent) {
        sendJSON(res, 502, { error: { message: 'Browser not connected. Set CDP_URL.', type: 'api_error' } });
      }
    }
  } else {
    // ── Non-streaming mode ──
    try {
      let result;
      
      // Use browser (handles captcha + streams response)
      stats.browserCalls++;
      const pageEntry = await getOrCreatePage(token);
      const events = [];
      await new Promise((resolve, reject) => {
        sendThroughBrowserStreaming(pageEntry, zaiBody,
          (chunk) => events.push(chunk),
          () => { result = { events }; resolve(); },
          reject
        );
      });

      // Parse events
      let content = '';
      let thinking = '';
      for (const ev of (result.events || [])) {
        if (ev.done || ev.error) continue;
        const c = ev.delta_content || ev.edit_content || ev.content || '';
        if (!c) continue;
        const phase = ev.phase || 'answer';
        if (phase === 'thinking') thinking += c;
        else content += c;
      }

      content = filterToolArtifacts(content);
      const msg = { role: 'assistant', content };
      
      // #8 Claude API reasoning separation
      if (thinking && THINK_MODE === 'reasoning') {
        msg.reasoning_content = thinking;
      } else if (thinking && THINK_MODE === 'think') {
        msg.content = `<think>\n${thinking}\n</think>\n\n${content}`;
      }

      const latency = Date.now() - startTime;
      stats.totalLatency += latency;
      stats.modelStats[model].totalLatency += latency;
      updateModelHealth(model, content.length > 0);

      sendJSON(res, 200, {
        id: 'chatcmpl-' + crypto.randomUUID().substring(0, 8),
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model,
        choices: [{ index: 0, message: msg, finish_reason: 'stop' }],
        usage: {
          prompt_tokens: estimateTokens(getLastUserContent(messages)),
          completion_tokens: estimateTokens(content),
          total_tokens: estimateTokens(getLastUserContent(messages)) + estimateTokens(content),
        },
      });
    } catch (e) {
      stats.errors++;
      if (stats.modelStats[model]) stats.modelStats[model].errors++;
      updateModelHealth(model, false);
      sendJSON(res, 502, { error: { message: e.message, type: 'api_error' } });
    }
  }
}

// ── Claude/Anthropic Messages Handler (#8 — reasoning separation) ──
function mapClaudeModel(model) {
  const mapped = MODEL_ALIASES[model];
  if (mapped) return mapped;
  if (model.startsWith('claude-opus')) return 'GLM-5.1';
  if (model.startsWith('claude-sonnet')) return 'GLM-5.1';
  if (model.startsWith('claude-haiku') || model.startsWith('claude-3-haiku')) return 'GLM-5-Turbo';
  return resolveModel(model);
}

function claudeToOpenAIMessages(req) {
  const messages = [];
  if (req.system) {
    let systemText = '';
    if (typeof req.system === 'string') systemText = req.system;
    else if (Array.isArray(req.system)) {
      systemText = req.system.filter(b => b.type === 'text').map(b => b.text).join('\n\n');
    }
    if (systemText) messages.push({ role: 'system', content: systemText });
  }

  for (const msg of req.messages || []) {
    const converted = { role: msg.role };
    if (typeof msg.content === 'string') {
      converted.content = msg.content;
    } else if (Array.isArray(msg.content)) {
      const parts = [];
      for (const block of msg.content) {
        if (block.type === 'text') parts.push({ type: 'text', text: block.text });
        else if (block.type === 'image') {
          if (block.source && block.source.type === 'base64') {
            parts.push({ type: 'image_url', image_url: { url: `data:${block.source.media_type};base64,${block.source.data}` } });
          }
        } else if (block.type === 'tool_result') {
          converted.role = 'tool';
          converted.content = typeof block.content === 'string' ? block.content
            : Array.isArray(block.content) ? block.content.map(c => c.text || '').join('\n') : '';
          converted.tool_call_id = block.tool_use_id;
        }
      }
      if (parts.length > 0 && !converted.tool_call_id) {
        converted.content = parts.length === 1 && parts[0].type === 'text' ? parts[0].text : parts;
      }
    }
    messages.push(converted);
  }
  return messages;
}

async function handleClaudeMessages(req, res) {
  stats.requests++;
  const startTime = Date.now();
  const body = await parseBody(req);
  const claudeModel = body.model || 'claude-sonnet-4-20250514';
  const zaiModel = mapClaudeModel(claudeModel);
  const stream = body.stream === true;
  const openaiMessages = claudeToOpenAIMessages(body);

  // #8 Reasoning separation for Claude
  let enableThinking = null;
  if (body.thinking && body.thinking.type === 'enabled') enableThinking = true;
  if (body.thinking && body.thinking.type === 'disabled') enableThinking = false;

  const token = extractRequestToken(req) || getLRUToken();
  if (!token) {
    return sendJSON(res, 503, { type: 'error', error: { type: 'api_error', message: 'No tokens' } });
  }

  const zaiBody = buildZAIBody(zaiModel, openaiMessages, { enableThinking });

  if (stream) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
      'X-Accel-Buffering': 'no',
    });

    const msgId = 'msg_' + crypto.randomUUID().substring(0, 12);
    let contentIdx = 0;
    let thinkingIdx = -1;
    let totalContent = '';
    let totalThinking = '';
    let prevPhase = '';
    let thinkingBlockStarted = false;

    // message_start
    sendClaudeSSE(res, 'message_start', {
      type: 'message_start',
      message: {
        id: msgId, type: 'message', role: 'assistant', model: claudeModel,
        content: [], usage: { input_tokens: 0, output_tokens: 0 },
      },
    });

    const processChunk = (ev) => {
      if (ev.done || ev.error) return;
      const content = ev.delta_content || ev.edit_content || ev.content || '';
      if (!content) return;

      const phase = ev.phase || 'answer';

      if (phase === 'thinking') {
        // #8: Send thinking as separate thinking block
        if (!thinkingBlockStarted && enableThinking) {
          thinkingIdx = contentIdx;
          sendClaudeSSE(res, 'content_block_start', {
            type: 'content_block_start', index: thinkingIdx,
            content_block: { type: 'thinking', thinking: '' },
          });
          contentIdx++;
          thinkingBlockStarted = true;
        }
        if (thinkingBlockStarted) {
          totalThinking += content;
          sendClaudeSSE(res, 'content_block_delta', {
            type: 'content_block_delta', index: thinkingIdx,
            delta: { type: 'thinking_delta', thinking: content },
          });
        }
      } else {
        // Close thinking block if transitioning
        if (thinkingBlockStarted && prevPhase === 'thinking') {
          sendClaudeSSE(res, 'content_block_stop', { type: 'content_block_stop', index: thinkingIdx });
          // Start text block
          sendClaudeSSE(res, 'content_block_start', {
            type: 'content_block_start', index: contentIdx,
            content_block: { type: 'text', text: '' },
          });
        } else if (prevPhase === '' || (prevPhase === 'thinking' && !thinkingBlockStarted)) {
          sendClaudeSSE(res, 'content_block_start', {
            type: 'content_block_start', index: contentIdx,
            content_block: { type: 'text', text: '' },
          });
        }
        
        totalContent += content;
        sendClaudeSSE(res, 'content_block_delta', {
          type: 'content_block_delta', index: contentIdx,
          delta: { type: 'text_delta', text: content },
        });
      }
      prevPhase = phase;
    };

    const finishStream = () => {
      // Close last block
      if (prevPhase === 'thinking' && thinkingBlockStarted) {
        sendClaudeSSE(res, 'content_block_stop', { type: 'content_block_stop', index: thinkingIdx });
        // Still need a text block even if empty
        sendClaudeSSE(res, 'content_block_start', {
          type: 'content_block_start', index: contentIdx,
          content_block: { type: 'text', text: '' },
        });
        sendClaudeSSE(res, 'content_block_stop', { type: 'content_block_stop', index: contentIdx });
      } else {
        sendClaudeSSE(res, 'content_block_stop', { type: 'content_block_stop', index: contentIdx });
      }

      sendClaudeSSE(res, 'message_delta', {
        type: 'message_delta',
        delta: { stop_reason: 'end_turn' },
        usage: { output_tokens: estimateTokens(totalContent + totalThinking) },
      });
      sendClaudeSSE(res, 'message_stop', { type: 'message_stop' });
      res.end();
      updateModelHealth(zaiModel, totalContent.length > 0);
    };

    // Use browser for streaming
    if (!browser) {
      return sendJSON(res, 502, { type: 'error', error: { type: 'api_error', message: 'Browser not connected' } });
    }
    try {
      const pageEntry = await getOrCreatePage(token);
      await new Promise((resolve, reject) => {
        sendThroughBrowserStreaming(pageEntry, zaiBody,
          processChunk,
          () => { finishStream(); resolve(); },
          (err) => reject(err)
        );
      });
    } catch (e) {
      if (!res.headersSent) {
        sendJSON(res, 502, { type: 'error', error: { type: 'api_error', message: e.message } });
      } else {
        res.end();
      }
    }
  } else {
    // Non-streaming Claude
    if (!browser) {
      return sendJSON(res, 502, { type: 'error', error: { type: 'api_error', message: 'Browser not connected' } });
    }
    try {
      const pageEntry = await getOrCreatePage(token);
      const events = [];
      await new Promise((resolve, reject) => {
        sendThroughBrowserStreaming(pageEntry, zaiBody,
          (chunk) => events.push(chunk),
          () => resolve(),
          reject
        );
      });
      
      let content = '';
      let thinking = '';
      for (const ev of events) {
        if (ev.done || ev.error) continue;
        const c = ev.delta_content || ev.edit_content || ev.content || '';
        if (!c) continue;
        if ((ev.phase || 'answer') === 'thinking') thinking += c;
        else content += c;
      }

      content = filterToolArtifacts(content);

      // #8: Separate thinking for Claude
      const contentBlocks = [];
      if (thinking && enableThinking) {
        contentBlocks.push({ type: 'thinking', thinking });
      }
      contentBlocks.push({ type: 'text', text: content });

      sendJSON(res, 200, {
        id: 'msg_' + crypto.randomUUID().substring(0, 12),
        type: 'message', role: 'assistant', model: claudeModel,
        content: contentBlocks,
        stop_reason: 'end_turn',
        usage: {
          input_tokens: estimateTokens(getLastUserContent(openaiMessages)),
          output_tokens: estimateTokens(content + thinking),
        },
      });
      updateModelHealth(zaiModel, content.length > 0);
    } catch (e) {
      stats.errors++;
      sendJSON(res, 502, { type: 'error', error: { type: 'api_error', message: e.message } });
    }
  }
}

// ── Models Handler (#10 — health check) ──
let cachedModels = null;
let modelsLastFetch = 0;

async function handleModels(req, res) {
  const token = extractRequestToken(req) || getNextToken();
  if (!token) {
    return sendJSON(res, 503, { error: { message: 'No tokens', type: 'api_error' } });
  }

  const now = Date.now();
  if (cachedModels && now - modelsLastFetch < 5 * 60 * 1000) {
    // Annotate with health status
    const models = cachedModels.map(m => ({
      ...m,
      status: getModelHealth(m.id),
    }));
    return sendJSON(res, 200, { object: 'list', data: models });
  }

  try {
    const resp = await fetch(`${ZAI_HOST}/api/models`, {
      headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' },
    });
    const data = await resp.json();
    const models = (data.data || data || []).map(m => ({
      id: m.id,
      object: 'model',
      created: m.created || Math.floor(Date.now() / 1000),
      owned_by: m.owned_by || 'z.ai',
      status: getModelHealth(m.id),
    }));

    cachedModels = models;
    modelsLastFetch = now;
    sendJSON(res, 200, { object: 'list', data: models });
  } catch (e) {
    sendJSON(res, 502, { error: { message: e.message, type: 'api_error' } });
  }
}

// ── Extract token from request ──
function extractRequestToken(req) {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) {
    const t = auth.substring(7);
    if (t.split('.').length === 3 && t.length > 100) return t;
  }
  const apiKey = req.headers['x-api-key'];
  if (apiKey && apiKey.split('.').length === 3) return apiKey;
  return '';
}

// ── CORS ──
function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key, anthropic-version, anthropic-beta');
}

// ── HTTP Server ──
const server = http.createServer(async (req, res) => {
  setCORS(res);
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  try {
    // Health
    if (path === '/health') {
      return sendJSON(res, 200, {
        status: 'ok', version: '2.0.0',
        mode: MODE,
        uptime: Math.floor((Date.now() - stats.startTime) / 1000),
        browser: !!browser,
        tokens: TOKENS.length,
      });
    }

    // Root
    if (path === '/') {
      return sendJSON(res, 200, {
        name: 'z2api', version: '2.0.0',
        description: 'OpenAI/Anthropic compatible proxy for Z.ai (v2 — Direct API + Real-time Streaming)',
        mode: MODE,
        features: [
          'Real-time SSE streaming',
          'Direct API mode (no browser overhead)',
          'Multi-token parallelism',
          'Rate limit queue with exponential backoff',
          'Model alias mapping (gpt-4/claude → GLM)',
          'Model health monitoring',
          'Thinking mode toggle',
          'Claude reasoning separation',
        ],
        endpoints: {
          models: '/v1/models',
          chat_completions: '/v1/chat/completions',
          messages: '/v1/messages',
          health: '/health',
          admin_stats: '/admin/stats',
        },
        model_aliases: MODEL_ALIASES,
      });
    }

    // Models
    if (path === '/v1/models') {
      return await handleModels(req, res);
    }

    // Chat completions
    if (path === '/v1/chat/completions' && req.method === 'POST') {
      return await handleChatCompletions(req, res);
    }

    // Claude Messages
    if ((path === '/v1/messages' || path === '/anthropic/v1/messages') && req.method === 'POST') {
      return await handleClaudeMessages(req, res);
    }

    // Admin stats
    if (path === '/admin/stats') {
      if (ADMIN_KEY && extractRequestToken(req) !== ADMIN_KEY) {
        return sendJSON(res, 401, { error: 'unauthorized' });
      }
      return sendJSON(res, 200, {
        ...stats,
        uptime: Math.floor((Date.now() - stats.startTime) / 1000),
        avgLatencyMs: stats.requests > 0 ? Math.round(stats.totalLatency / stats.requests) : 0,
        pagePool: pagePool.size,
        tokens: TOKENS.length,
        mode: MODE,
        modelHealth: Object.fromEntries(modelHealth),
      });
    }

    sendJSON(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error('[server] Error:', e);
    if (!res.headersSent) {
      sendJSON(res, 500, { error: { message: e.message, type: 'server_error' } });
    }
  }
});

// ── Startup ──
async function main() {
  console.log('='.repeat(60));
  console.log('  Z2API v2 — OpenAI/Anthropic Proxy for Z.ai');
  console.log('  Improvements: Direct API + Real-time Streaming');
  console.log('='.repeat(60));
  console.log(`  Port:        ${PORT}`);
  console.log(`  Mode:        ${MODE} (direct/browser/auto)`);
  console.log(`  Think Mode:  ${THINK_MODE} (reasoning/think/strip)`);
  console.log(`  Timeout:     ${REQUEST_TIMEOUT / 1000}s`);
  console.log(`  Debug:       ${DEBUG}`);
  console.log(`  Tokens:      ${TOKENS.length} configured`);
  console.log(`  CDP URL:     ${CDP_URL}`);
  console.log('-'.repeat(60));
  console.log('  Endpoints:');
  console.log('    GET  /v1/models            — List models (with health)');
  console.log('    POST /v1/chat/completions  — OpenAI chat (streaming!)');
  console.log('    POST /v1/messages          — Anthropic messages');
  console.log('    GET  /health               — Health check');
  console.log('    GET  /admin/stats          — Admin statistics');
  console.log('-'.repeat(60));
  console.log('  Model Aliases:');
  console.log('    gpt-4, gpt-4o          → GLM-5.1');
  console.log('    gpt-3.5-turbo, gpt-4o-mini → GLM-5-Turbo');
  console.log('    gpt-4-vision-preview   → GLM-5V-Turbo');
  console.log('='.repeat(60));

  // Always connect browser (required for captcha handling)
  await initBrowser();

  server.listen(PORT, () => {
    console.log(`[server] Listening on :${PORT}`);
    console.log(`[server] Base URL: http://localhost:${PORT}/v1`);
  });
}

main().catch(e => {
  console.error('Fatal:', e);
  process.exit(1);
});
